INSIGHT SYNC User Guide placeholder

The application will look for the final PDF in one of these locations at runtime:

1) Assets\Docs\INSIGHT_SYNC_User_Guide.pdf
2) Docs\INSIGHT_SYNC_User_Guide.pdf
3) INSIGHT_SYNC_User_Guide.pdf beside the executable

Next step:
- Generate the final PDF User Guide.
- Copy it as:
  InsightSync.UI\Assets\Docs\INSIGHT_SYNC_User_Guide.pdf
- Set the file build action to Content if the project does not already include Assets/Docs content automatically.
